package movieTicket;

public class ListedMovies extends AbstractEvent {

    private Long id;
    private String movieName;

    public ListedMovies(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }
}
